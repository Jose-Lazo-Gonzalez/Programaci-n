print("-----------------------------------------------------")
print("-----------------------------------------------------")
print("SOMBRERO SELECCIONADOR")
print("-----------------------------------------------------")
print("-----------------------------------------------------")
print("1. Selecciona casa para un alumno")
print("2.Mostrar estadisticas")
print("Elige una opción. Si quieres salir del programa, escribe la opcion 1 y el nombre del personaje innombrable")
menu=int(input("Selecciona una opcion"))
while menu!=1 and menu!=2:
    menu=int(input("Selecciona una opcion"))
if menu ==1:
    print("Ejecutando y seleccionando casa")
if menu ==2:
    print("Ejecutando y mostrando estadisticas")
